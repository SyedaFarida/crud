﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string emailPattern = @"^[0-9]{5}-[0-9]{7}-[0-9]{1}$";
            bool isEmailValid = Regex.IsMatch(textBox3.Text, emailPattern);
           
            if (isEmailValid)
            {
                MessageBox.Show("valid");
            }
            else
            {
                MessageBox.Show("invalid");
            }
            
           // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=practice;Persist Security Info=True;User ID=sa;Password=abc123+");
         
           // SqlCommand SelectCommand =new SqlCommand( "select * from tbl_user where userId='" + textBox1.Text + "' and Password='" + textBox2.Text + "'",con);
           //SqlDataReader myReader;

           //         con.Open();
           //         myReader = SelectCommand.ExecuteReader();
           //         int count = 0;
           //         string userRole = string.Empty;
           // string status=string.Empty;
           //         while (myReader.Read())
           //         {
           //             count = count + 1;
           //             userRole = myReader["Role"].ToString();
           //             status = myReader["Status"].ToString();
           //         }
           //         if (count == 1)
           //         {
           //             MessageBox.Show("Username and Password . . . is Correct", "Confirmation Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
           //             this.Hide();
           //             if(userRole =="Admin" && status=="active"){
           //             userpanel obj=new userpanel();
           //                 obj.Show();
                        
                        
           //             }
                        
           //             else{
           //                 admin ob = new admin();
           //                 ob.Show();
                     
                        
                        
           //             }
           //             //show user window
                       
           // }
           //         else
           //         {
           //             MessageBox.Show("invalid user");

           //         }
                
            
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
