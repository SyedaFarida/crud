﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication22
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=practice;Persist Security Info=True;User ID=sa;Password=abc123+");
         SqlDataAdapter adapt;  
        DataTable dt; 
        private void admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'practiceDataSet.tbl_1' table. You can move, or remove it, as needed.
            this.tbl_1TableAdapter.Fill(this.practiceDataSet.tbl_1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
       
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            con.Open();
             
            adapt = new SqlDataAdapter("select * from tbl_1 where name like '%"+textBox1.Text+"%'", con);  
            dt = new DataTable();  
            adapt.Fill(dt);  
            dataGridView1.DataSource = dt;  
            con.Close();  
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            Form2 ob = new Form2();
            ob.Show();
         
          
        }  
        }
    }

