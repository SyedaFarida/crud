﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApplication22
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=practice;Persist Security Info=True;User ID=sa;Password=***********Data Source=.;Initial Catalog=practice;Persist Security Info=True;User ID=sa;Password=abc123+");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into tbl_1 values ('" + txt_id.Text + "','" + textBox2.Text + "','" + dateTimePicker1.Value + "','"+textBox3.Text+"','"+textBox4.Text+"')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("inserted successfully");
            admin ob = new admin();
            ob.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //var a = dataGridView1.CurrentRow.Cells;
            //txt_id.Text = a[0].Value.ToString();
            //textBox4.Text = a[1].Value.ToString();
            //dateTimePicker1.Value = Convert.ToDateTime(a[2].Value);
            //textBox2.Text = a[3].Value.ToString();
            //textBox3.Text = a[4].Value.ToString();
            
        }
    }
}
